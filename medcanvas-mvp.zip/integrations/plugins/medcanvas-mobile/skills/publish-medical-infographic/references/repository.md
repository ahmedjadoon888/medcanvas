# Publishing destination

This plugin is configured for the MedCanvas repository below.

- Repository: `ahmedjadoon888/medcanvas`
- Branch: `main`
- GitHub Pages URL: `https://ahmedjadoon888.github.io/medcanvas/`

Keep the repository public while it is hosted on the free GitHub Pages plan. Do not put access tokens in this file.

## Fixed GitHub workflow allowlist

- Use only the required connected GitHub app.
- Read only repository `ahmedjadoon888/medcanvas` at branch/ref `main`.
- Create or update only `published/<slug>.json` and `published/index.json` on `main`.
- Slugs must match `^[a-z0-9]+(?:-[a-z0-9]+)*$` and must not equal `index`.
- Never upload the source medical reference image, any crop, encoded image bytes, raw transcription dump, or patient information.
- No other file writes, deletes, branches, pull requests, issues, comments, releases, settings changes, or permission changes.
- Check every call against this allowlist and stop if the available tool cannot enforce the destination and changed-path set.
- This allowlist governs this skill's use of GitHub; it does not change account-level app permissions.

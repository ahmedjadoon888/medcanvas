# Publishing destination

Configure this file before packaging the plugin.

- Repository: `OWNER/REPOSITORY`
- Branch: `main`
- GitHub Pages URL: `https://OWNER.github.io/REPOSITORY/`

Replace `OWNER` and `REPOSITORY` with the actual GitHub values. Keep the repository public if it is hosted on the free GitHub Pages plan. Do not put access tokens in this file.

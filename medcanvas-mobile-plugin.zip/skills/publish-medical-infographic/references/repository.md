# Publishing destination

This plugin is configured for the MedCanvas repository below.

- Repository: `ahmedjadoon888/medcanvas`
- Branch: `main`
- GitHub Pages URL: `https://ahmedjadoon888.github.io/medcanvas/`

Keep the repository public while it is hosted on the free GitHub Pages plan. Do not put access tokens in this file.

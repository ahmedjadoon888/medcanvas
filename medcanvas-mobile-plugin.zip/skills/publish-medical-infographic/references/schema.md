# MedCanvas publish schema

Write one topic document to `published/<slug>.json`:

```json
{
  "version": 1,
  "title": "Short topic title",
  "subtitle": "Recognition, evaluation & key cautions",
  "layout": "clinical-grid",
  "theme": "sage",
  "updated": "September 2026",
  "sections": [
    {
      "heading": "Recognize the pattern",
      "icon": "clinical",
      "accent": "coral",
      "items": ["Concise source-faithful statement"]
    }
  ],
  "callout": "One important warning or interpretation caveat.",
  "sources": [
    { "label": "Organization — document title", "url": "https://authoritative.example/path" }
  ],
  "note": "For education only · Verify local guidance · Not medical advice",
  "review": {
    "sourceType": "reference screenshot",
    "uncertainties": [],
    "verifiedAt": "2026-09-28"
  }
}
```

Allowed layouts are `clinical-grid`, `pathway`, and `compare`. Allowed themes are `sage`, `cobalt`, and `plum`. Use two to four sections, one to three items per section, and no more than 115 characters per item. Valid icons are `clinical`, `blood`, `stomach`, `lab`, `pathway`, and `compare`. Valid accents are `coral`, `gold`, `blue`, and `sage`.

Prepend this entry to `published/index.json`:

```json
{
  "slug": "short-topic-slug",
  "title": "Short topic title",
  "subtitle": "Recognition, evaluation & key cautions",
  "theme": "sage",
  "updated": "2026-09-28T12:00:00.000Z",
  "data": "published/short-topic-slug.json"
}
```

The index is a JSON array. Remove an existing entry with the same slug before prepending the new one. Do not include the source screenshot or any patient information.

---
name: publish-medical-infographic
description: Turn an uploaded medical reference screenshot or camera photo into deterministic MedCanvas infographic data and publish it to a configured GitHub Pages repository. Use when the user asks to make, post, or publish a medical infographic from an image. Do not use for interpreting diagnostic imaging or patient-specific medical advice.
---

# Publish Medical Infographic

Convert the user's uploaded screenshot into a public MedCanvas item with minimal interaction.

## Required configuration

Read the publishing destination in [references/repository.md](references/repository.md). If it still contains `OWNER/REPOSITORY`, the user must provide the repository once in the conversation. Use the connected GitHub app for repository reads and writes. If no GitHub write tool is available, ask the user to install or connect the official GitHub plugin; do not request a personal access token in chat.

Read [references/schema.md](references/schema.md) before the first publish in a conversation.

## Workflow

When a user attaches a medical-reference screenshot or camera photo and asks to create/publish an infographic:

1. Inspect the image for patient names, dates of birth, MRNs, addresses, encounter dates, barcodes, faces, or other identifying information. If any may be present, stop before external writes and tell the user to crop or redact the image. Do not upload the source image to GitHub.
2. Transcribe the clinically relevant text faithfully. Preserve numbers, units, inequality signs, qualifications, and negation. Mark unreadable text as uncertain; never guess it.
3. Organize the content into two to four short sections using the schema reference. Keep each bullet concise enough for a 1080 × 1350 graphic. Do not add treatment doses or thresholds that are absent from the source unless independently verified.
4. When web search is available, verify high-impact claims, doses, thresholds, and warnings against current primary or authoritative clinical sources. Prefer government guidance, professional society guidelines, official drug labeling, and peer-reviewed reviews. Record the source links. If the screenshot conflicts with current guidance or remains ambiguous, do not auto-publish: explain the discrepancy and ask for a decision.
5. Create a lowercase hyphenated slug. Read `published/index.json` from the configured repository. Prepare the topic JSON at `published/<slug>.json` and prepend its manifest entry to the gallery index, removing any older entry with the same slug and retaining at most 24 entries.
6. Use the connected GitHub write capability to commit both files to the Pages branch. Publishing is an external write; honor any approval prompt shown by ChatGPT or the GitHub app. Do not ask an additional conversational confirmation when the user's message already says to publish and the checks above pass.
7. Return the GitHub Pages gallery URL and say that deployment may take a short time. Mention any uncertainty that survived review.

## Non-negotiable boundaries

- This creates educational visuals, not patient-specific advice.
- Never publish a source screenshot, protected health information, or copyrighted page image.
- Do not claim that automated extraction establishes scientific accuracy.
- Never invent citations or represent a secondary summary as a primary guideline.
- Do not publish when a critical number, unit, drug, or negation is unreadable.
- Keep text deterministic by publishing structured JSON only. The MedCanvas site performs the SVG/PNG rendering.
